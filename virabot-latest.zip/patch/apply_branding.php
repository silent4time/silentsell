<?php
$candidates = [
    getcwd() . '/lang/fa.php',
    __DIR__ . '/lang/fa.php',
    dirname(__DIR__) . '/lang/fa.php',
];
$fa = null;
foreach ($candidates as $c) {
    if (is_file($c)) { $fa = $c; break; }
}
if (!$fa) {
    fwrite(STDERR, "lang/fa.php not found\n");
    exit(1);
}
$t = file_get_contents($fa);
$orig = $t;

function sb_set_text(string $src, string $key, string $value, &$count): string
{
    $count = 0;
    $quoted = "'" . str_replace(['\\', "'"], ['\\\\', "\\'"], $value) . "'";
    $out = preg_replace_callback(
        "/('" . preg_quote($key, '/') . "'\\s*=>\\s*)'(?:[^'\\\\]|\\\\.)*'/s",
        function ($m) use ($quoted) { return $m[1] . $quoted; },
        $src,
        -1,
        $count
    );
    return $out === null ? $src : $out;
}

// Admin panel header. The single %s is the content of the "version" file; admin.php
// runs sprintf on it twice, so the text must keep exactly one %s and no other "%".
$adminAbout = '💎 | Version Bot: %s
📌 | Version Mini App: 0.1.1

<blockquote>🔑 | ویرابات رایگان نیست و با کد فعالسازی ویراکد ارائه می‌شود.</blockquote>

<blockquote>🛒 | برای خرید یا تمدید کد فعالسازی به آیدی تلگرام @silentpingvpn پیام دهید:
https://t.me/silentpingvpn</blockquote>

<blockquote>🐞 | اگر در عملکرد ربات با باگ یا مشکلی مواجه شدید، از دکمهٔ «📬 گزارش ربات» در پنل ادمین با ما در ارتباط باشید.</blockquote>';

$hits = 0;
foreach (['msg_panel_admin_bot_report', 'aboutBot'] as $key) {
    $t = sb_set_text($t, $key, $adminAbout, $n);
    if ($n > 0) {
        echo "OK {$key}\n";
        $hits += $n;
    }
}
if ($hits === 0) {
    echo "WARN admin about text not found\n";
}

$newReport = '💬 | گزارش ربات

🔹 | اگر در عملکرد ربات با باگ یا مشکلی روبه‌رو شدید، لطفاً مورد را برای بررسی به ما اطلاع دهید.
➖➖➖➖➖➖➖➖➖➖➖
🔹 | در صورتی که با باگ جدی یا رفتار غیرعادی مواجه شدید، سریع‌تر گزارش دهید تا رفع شود.
➖➖➖➖➖➖➖➖➖➖➖
🔹 | اگر پیشنهادی برای افزودن قابلیت جدید دارید یا ایده‌ای برای بهبود عملکرد ربات در نظر دارید، خوشحال می‌شویم بشنویم.
➖➖➖➖➖➖➖➖➖➖➖
🔹 | همچنین اگر نیاز به راهنمایی یا کمک دارید، می‌توانید از طریق دایرکت با تیم پشتیبانی در ارتباط باشید.

📩 | برای ارسال گزارش، پیشنهاد یا درخواست راهنمایی، ایمیل بگذارید:
<a href="mailto:silentping.vpn@gmail.com">silent4time</a> (silentping.vpn@gmail.com)';
$t = sb_set_text($t, 'botReportIntro', $newReport, $n);
echo $n > 0 ? "OK botReportIntro\n" : "WARN botReportIntro not found\n";

if ($t === $orig) {
    echo "No change\n";
    exit(0);
}
$check = @eval('?>' . $t);
if (!is_array($check)) {
    fwrite(STDERR, "branded lang file does not evaluate to an array; not saved\n");
    exit(1);
}
file_put_contents($fa, $t);
echo "OK saved: $fa\n";
exit(0);
